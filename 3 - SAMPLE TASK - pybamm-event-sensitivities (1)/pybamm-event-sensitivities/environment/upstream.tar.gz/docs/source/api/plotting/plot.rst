Plot
====

.. autofunction:: pybamm.plot
